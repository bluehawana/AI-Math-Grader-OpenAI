module.exports=[56992,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_grade-image_route_actions_5a6df8fc.js.map