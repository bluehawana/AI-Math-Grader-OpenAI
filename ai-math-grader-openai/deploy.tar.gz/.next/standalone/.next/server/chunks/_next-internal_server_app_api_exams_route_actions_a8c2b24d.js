module.exports=[85610,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_exams_route_actions_a8c2b24d.js.map