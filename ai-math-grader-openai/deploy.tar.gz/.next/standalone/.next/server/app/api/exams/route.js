var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/exams/route.js")
R.c("server/chunks/[root-of-the-server]__ea44a03f._.js")
R.c("server/chunks/[root-of-the-server]__b69ad51f._.js")
R.c("server/chunks/node_modules_next_1402a1da._.js")
R.c("server/chunks/_next-internal_server_app_api_exams_route_actions_a8c2b24d.js")
R.m(9726)
module.exports=R.m(9726).exports
